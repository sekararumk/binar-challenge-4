import React from 'react'

const InfoMobil = () => {
  return (
    <div>InfoMobil</div>
  )
}

export default InfoMobil